import { useEffect } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Navigation from './sections/Navigation'
import Hero from './sections/Hero'
import DocumentVault from './sections/DocumentVault'
import VideoShowcase from './sections/VideoShowcase'
import Principles from './sections/Principles'
import Architecture from './sections/Architecture'
import Engines from './sections/Engines'
import Audit from './sections/Audit'
import Timeline from './sections/Timeline'
import CTA from './sections/CTA'
import Footer from './sections/Footer'
import MachineBot from './sections/MachineBot'

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    })

    lenis.on('scroll', ScrollTrigger.update)

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000)
    })

    gsap.ticker.lagSmoothing(0)

    return () => {
      lenis.destroy()
      gsap.ticker.remove(lenis.raf as any)
    }
  }, [])

  return (
    <div className="min-h-[100dvh]" style={{ background: '#0A1628' }}>
      <Navigation />
      <Hero />
      <DocumentVault />
      <VideoShowcase />
      <Principles />
      <Architecture />
      <Engines />
      <Audit />
      <Timeline />
      <CTA />
      <Footer />
      <MachineBot />
    </div>
  )
}
