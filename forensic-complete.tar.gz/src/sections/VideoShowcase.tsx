import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const stats = [
  { value: '5', label: 'Canonical system layers', color: '#E85D4C' },
  { value: '14+', label: 'Specialized forensic engines', color: '#D4A03A' },
  { value: '100%', label: 'Source-anchor coverage required', color: '#3B8EA5' },
]

function PerspectiveHeading({ text: _text, revealedValue }: { text: string; revealedValue: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = textRef.current
    if (!el) return

    const chars = el.querySelectorAll('span')
    chars.forEach((span, idx) => {
      ;(span as HTMLElement).style.transitionDelay = `${idx * 0.04}s`
    })

    const trigger = ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top 80%',
      end: 'top 30%',
      onEnter: () => el.classList.add('revealed'),
      onLeaveBack: () => el.classList.remove('revealed'),
    })

    return () => {
      trigger.kill()
    }
  }, [])

  // Split revealedValue into individual characters
  const characters = revealedValue.split('')

  return (
    <div ref={containerRef} className="perspective-container flex items-center justify-center py-8">
      <div
        ref={textRef}
        className="rotate-text font-light uppercase tracking-[-2px] text-[#E2E8F0] text-center"
        style={{
          fontFamily: "'Geist', sans-serif",
          fontSize: 'clamp(36px, 6vw, 80px)',
          transformStyle: 'preserve-3d',
        }}
      >
        {characters.map((char: string, idx: number) => (
          <span key={idx} style={{ display: char === ' ' ? 'inline' : 'inline-block', width: char === ' ' ? '0.4em' : undefined }}>
            {char === ' ' ? '\u00A0' : char}
          </span>
        ))}
      </div>
    </div>
  )
}

export default function VideoShowcase() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<HTMLDivElement>(null)
  const videoContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    const cards = cardsRef.current
    const videoContainer = videoContainerRef.current
    if (!section || !cards || !videoContainer) return

    // Video container entrance
    gsap.fromTo(
      videoContainer,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: videoContainer,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      }
    )

    // Stat cards stagger
    const cardEls = cards.querySelectorAll('.stat-card')
    gsap.fromTo(
      cardEls,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.12,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: cards,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  return (
    <section
      id="showcase"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <p className="section-label mb-6">01 — SYSTEM OVERVIEW</p>

        <PerspectiveHeading text="WHERETRUTH" revealedValue="WHERE TRUTH" />

        {/* Video Placeholder with animated pipeline visualization */}
        <div
          ref={videoContainerRef}
          className="relative w-full max-w-[1000px] mx-auto mb-16 rounded-lg overflow-hidden"
          style={{
            aspectRatio: '16/9',
            background: '#111D32',
            border: '1px solid rgba(100, 116, 139, 0.15)',
          }}
        >
          <PipelineAnimation />
        </div>

        {/* Stat Cards */}
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, i) => (
            <div
              key={i}
              className="stat-card p-8 rounded-lg"
              style={{
                background: '#111D32',
                border: '1px solid rgba(100, 116, 139, 0.15)',
                borderRadius: '8px',
              }}
            >
              <p
                className="text-[48px] font-light mb-2"
                style={{ fontFamily: "'Geist', sans-serif", color: stat.color }}
              >
                {stat.value}
              </p>
              <p className="font-geist-mono text-[11px] uppercase tracking-[2px] text-[#64748B]">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Pipeline animation as a React component using canvas
function PipelineAnimation() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const w = rect.width
    const h = rect.height

    interface Particle {
      t: number
      speed: number
      pathIndex: number
      size: number
    }

    const particles: Particle[] = []
    for (let i = 0; i < 20; i++) {
      particles.push({
        t: Math.random(),
        speed: 0.003 + Math.random() * 0.005,
        pathIndex: Math.floor(Math.random() * 3),
        size: 1.5 + Math.random() * 2,
      })
    }

    const nodes = [
      { x: w * 0.08, y: h * 0.5, label: 'VAULT', color: '#E85D4C' },
      { x: w * 0.22, y: h * 0.5, label: 'CLASSIFY', color: '#D4A03A' },
      { x: w * 0.36, y: h * 0.5, label: 'EXTRACT', color: '#3B8EA5' },
      { x: w * 0.5, y: h * 0.5, label: 'LEDGER', color: '#E85D4C' },
      { x: w * 0.64, y: h * 0.5, label: 'CHRONO', color: '#D4A03A' },
      { x: w * 0.78, y: h * 0.5, label: 'AUDIT', color: '#3B8EA5' },
      { x: w * 0.92, y: h * 0.5, label: 'EXPORT', color: '#E85D4C' },
    ]

    const bezierPaths = [
      { cp1x: w * 0.15, cp1y: h * 0.3, cp2x: w * 0.29, cp2y: h * 0.7 },
      { cp1x: w * 0.29, cp1y: h * 0.7, cp2x: w * 0.43, cp2y: h * 0.3 },
      { cp1x: w * 0.43, cp1y: h * 0.3, cp2x: w * 0.57, cp2y: h * 0.7 },
      { cp1x: w * 0.57, cp1y: h * 0.7, cp2x: w * 0.71, cp2y: h * 0.3 },
      { cp1x: w * 0.71, cp1y: h * 0.3, cp2x: w * 0.85, cp2y: h * 0.7 },
      { cp1x: w * 0.85, cp1y: h * 0.7, cp2x: w * 0.99, cp2y: h * 0.5 },
    ]

    function getBezierPoint(t: number, from: { x: number; y: number }, to: { x: number; y: number }, cp: { cp1x: number; cp1y: number; cp2x: number; cp2y: number }) {
      const u = 1 - t
      return {
        x: u * u * u * from.x + 3 * u * u * t * cp.cp1x + 3 * u * t * t * cp.cp2x + t * t * t * to.x,
        y: u * u * u * from.y + 3 * u * u * t * cp.cp1y + 3 * u * t * t * cp.cp2y + t * t * t * to.y,
      }
    }

    let time = 0

    const draw = () => {
      time += 0.016
      ctx.clearRect(0, 0, w, h)

      // Draw connections
      for (let i = 0; i < nodes.length - 1; i++) {
        const from = nodes[i]
        const to = nodes[i + 1]
        const cp = bezierPaths[i]

        // Draw faint path line
        ctx.beginPath()
        ctx.moveTo(from.x, from.y)
        ctx.bezierCurveTo(cp.cp1x, cp.cp1y, cp.cp2x, cp.cp2y, to.x, to.y)
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.15)'
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw traveling glow on path
        const glowT = (time * 0.3 + i * 0.16) % 1
        const glowPos = getBezierPoint(glowT, from, to, cp)
        const gradient = ctx.createRadialGradient(glowPos.x, glowPos.y, 0, glowPos.x, glowPos.y, 40)
        gradient.addColorStop(0, 'rgba(232, 93, 76, 0.3)')
        gradient.addColorStop(1, 'rgba(232, 93, 76, 0)')
        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.arc(glowPos.x, glowPos.y, 40, 0, Math.PI * 2)
        ctx.fill()
      }

      // Draw particles
      particles.forEach((p) => {
        p.t += p.speed
        if (p.t > 1) p.t = 0

        const nodeFromIndex = Math.floor(p.t * (nodes.length - 1))
        const nodeToIndex = Math.min(nodeFromIndex + 1, nodes.length - 1)
        const localT = (p.t * (nodes.length - 1)) - nodeFromIndex

        if (nodeFromIndex < bezierPaths.length) {
          const pos = getBezierPoint(
            localT,
            nodes[nodeFromIndex],
            nodes[nodeToIndex],
            bezierPaths[nodeFromIndex]
          )

          ctx.beginPath()
          ctx.arc(pos.x, pos.y, p.size, 0, Math.PI * 2)
          ctx.fillStyle = nodes[nodeFromIndex].color
          ctx.fill()
        }
      })

      // Draw nodes
      nodes.forEach((node, i) => {
        // Glow
        const glowSize = 20 + Math.sin(time * 2 + i) * 5
        const gradient = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, glowSize)
        gradient.addColorStop(0, `${node.color}40`)
        gradient.addColorStop(1, 'transparent')
        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.arc(node.x, node.y, glowSize, 0, Math.PI * 2)
        ctx.fill()

        // Hexagon shape
        ctx.beginPath()
        for (let j = 0; j < 6; j++) {
          const angle = (Math.PI / 3) * j - Math.PI / 6
          const hx = node.x + 22 * Math.cos(angle)
          const hy = node.y + 22 * Math.sin(angle)
          if (j === 0) ctx.moveTo(hx, hy)
          else ctx.lineTo(hx, hy)
        }
        ctx.closePath()
        ctx.fillStyle = '#111D32'
        ctx.fill()
        ctx.strokeStyle = node.color
        ctx.lineWidth = 1.5
        ctx.stroke()

        // Label
        ctx.fillStyle = '#64748B'
        ctx.font = "400 9px 'Geist Mono', monospace"
        ctx.textAlign = 'center'
        ctx.fillText(node.label, node.x, node.y - 32)

        // Inner dot
        ctx.beginPath()
        ctx.arc(node.x, node.y, 3, 0, Math.PI * 2)
        ctx.fillStyle = node.color
        ctx.fill()
      })

      rafRef.current = requestAnimationFrame(draw)
    }

    rafRef.current = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(rafRef.current)
    }
  }, [])

  return <canvas ref={canvasRef} className="w-full h-full" />
}
