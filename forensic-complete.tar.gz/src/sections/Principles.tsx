import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Clock, Quote, Scale, GitBranch, SearchAlert } from 'lucide-react'

const principles = [
  {
    title: 'Chronology before narrative',
    description:
      'Talks with courts, regulators, and witnesses usually fail when date order is corrupted. PD 32 insists on chronological witness evidence.',
    icon: Clock,
    accent: '#E85D4C',
  },
  {
    title: 'Quotation fidelity',
    description:
      'If wording matters, the output must preserve the exact text and source span, not paraphrase it. Any edit breaks the audit chain.',
    icon: Quote,
    accent: '#D4A03A',
  },
  {
    title: 'Authority hierarchy',
    description:
      'Legislation in force outranks guidance. Official judgments outrank secondary summaries. Internal documents outrank model priors.',
    icon: Scale,
    accent: '#3B8EA5',
  },
  {
    title: 'Versioned legality',
    description:
      "The platform must know not just 'what rule exists', but 'what rule was in force on the relevant date'. Stale guidance is flagged, not silently merged.",
    icon: GitBranch,
    accent: '#E85D4C',
  },
  {
    title: 'Forensic humility',
    description:
      'Where the record does not establish a point, the system must say so in plain terms and record the uncertainty.',
    icon: SearchAlert,
    accent: '#D4A03A',
  },
]

export default function Principles() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cards = cardsRef.current
    if (!cards) return

    const cardEls = cards.querySelectorAll('.principle-card')
    gsap.fromTo(
      cardEls,
      { opacity: 0, x: 60 },
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        stagger: 0.15,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: cards,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  return (
    <section
      id="principles"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row gap-12 md:gap-16">
          {/* Left column */}
          <div className="md:w-[45%]">
            <p className="section-label mb-6">02 — PRINCIPLES</p>
            <h2
              className="text-[36px] md:text-[48px] font-light leading-[1.1] text-[#E2E8F0]"
              style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}
            >
              No source, no fact.
            </h2>
          </div>

          {/* Right column — Principle cards */}
          <div ref={cardsRef} className="md:w-[55%] flex flex-col gap-4">
            {principles.map((principle, i) => {
              const Icon = principle.icon
              return (
                <div
                  key={i}
                  className="principle-card p-6 rounded-lg group cursor-default"
                  style={{
                    background: '#111D32',
                    border: '1px solid rgba(100, 116, 139, 0.1)',
                    borderRadius: '8px',
                    borderLeft: `3px solid ${principle.accent}`,
                    transition: 'border-color 0.3s ease',
                  }}
                  onMouseEnter={(e) => {
                    ;(e.currentTarget as HTMLElement).style.borderColor = `${principle.accent}40`
                  }}
                  onMouseLeave={(e) => {
                    ;(e.currentTarget as HTMLElement).style.borderColor = 'rgba(100, 116, 139, 0.1)'
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ background: `${principle.accent}15` }}
                    >
                      <Icon size={18} color={principle.accent} strokeWidth={1.5} />
                    </div>
                    <div>
                      <h3 className="text-lg font-normal text-[#E2E8F0] mb-2">{principle.title}</h3>
                      <p className="text-sm font-light text-[#64748B] leading-relaxed">
                        {principle.description}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
