import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const phases = [
  {
    num: '01',
    title: 'Discovery',
    duration: '4-6 weeks',
    description: 'Matter taxonomy, jurisdiction profiles, UK rule packs',
  },
  {
    num: '02',
    title: 'Core Vault',
    duration: '8-10 weeks',
    description: 'Immutable vault, Postgres ledger, hashing, auth',
  },
  {
    num: '03',
    title: 'Chronology',
    duration: '8-12 weeks',
    description: 'Classifiers, date extraction, entity resolution, search',
  },
  {
    num: '04',
    title: 'Legal Mapping',
    duration: '8-12 weeks',
    description: 'Authority engine, element maps, disclosure generator',
  },
  {
    num: '05',
    title: 'Drafting',
    duration: '8-10 weeks',
    description: 'WS, POC, LBA templates; source-linked export; e-bundles',
  },
  {
    num: '06',
    title: 'Audit & Pilot',
    duration: '6-12 weeks',
    description: 'Full audit engine, transparency log, red/blue review',
  },
]

export default function Timeline() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cards = cardsRef.current
    if (!cards) return

    const cardEls = cards.querySelectorAll('.phase-card')
    gsap.fromTo(
      cardEls,
      { opacity: 0, y: 60 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: cards,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  return (
    <section
      id="timeline"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <p className="section-label mb-6">06 — IMPLEMENTATION</p>
        <h2
          className="text-[36px] md:text-[48px] font-light leading-[1.1] text-[#E2E8F0] mb-12"
          style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}
        >
          Built in six phases
        </h2>

        {/* Horizontal timeline — desktop */}
        <div ref={cardsRef} className="hidden md:grid grid-cols-6 gap-4">
          {phases.map((phase, i) => (
            <div
              key={i}
              className="phase-card p-5 rounded-lg relative"
              style={{
                background: '#111D32',
                border: '1px solid rgba(100, 116, 139, 0.1)',
                borderRadius: '8px',
                minHeight: '220px',
              }}
            >
              <p
                className="font-geist-mono text-[48px] font-light mb-3"
                style={{ color: 'rgba(232, 93, 76, 0.2)' }}
              >
                {phase.num}
              </p>
              <h3 className="text-lg font-normal text-[#E2E8F0] mb-2">{phase.title}</h3>
              <p className="font-geist-mono text-[11px] uppercase tracking-[1px] text-[#D4A03A] mb-3">
                {phase.duration}
              </p>
              <p className="text-sm font-light text-[#64748B] leading-relaxed">
                {phase.description}
              </p>

              {/* Connector line (except last) */}
              {i < phases.length - 1 && (
                <div
                  className="absolute top-8 -right-4 w-8 h-px"
                  style={{ background: 'rgba(100, 116, 139, 0.2)' }}
                />
              )}
            </div>
          ))}
        </div>

        {/* Vertical timeline — mobile */}
        <div className="md:hidden flex flex-col gap-4">
          {phases.map((phase, i) => (
            <div
              key={i}
              className="phase-card p-5 rounded-lg"
              style={{
                background: '#111D32',
                border: '1px solid rgba(100, 116, 139, 0.1)',
                borderRadius: '8px',
              }}
            >
              <div className="flex items-start gap-4">
                <p
                  className="font-geist-mono text-[36px] font-light leading-none flex-shrink-0"
                  style={{ color: 'rgba(232, 93, 76, 0.2)' }}
                >
                  {phase.num}
                </p>
                <div>
                  <h3 className="text-base font-normal text-[#E2E8F0] mb-1">{phase.title}</h3>
                  <p className="font-geist-mono text-[10px] uppercase tracking-[1px] text-[#D4A03A] mb-2">
                    {phase.duration}
                  </p>
                  <p className="text-sm font-light text-[#64748B] leading-relaxed">
                    {phase.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
