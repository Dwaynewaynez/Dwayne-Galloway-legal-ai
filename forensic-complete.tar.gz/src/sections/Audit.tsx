import { useEffect, useRef, useState, useCallback } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const rules = [
  'FACT_ACCOUNT_RESTRICTION: source_anchor required',
  'QUOTE_EXACTNESS: byte_exact after normalisation',
  'LAW_AUTHORITY: neutral citation or official case link',
  'CHRONOLOGY_EVENT: precedence rule, record alternatives',
]

const highlightedTerms = [
  { text: 'PRIMARY LEG', row: 2, col: 5, color: '#E2E8F0' },
  { text: 'PROC RULES', row: 8, col: 8, color: '#D4A03A' },
  { text: 'CASE LAW', row: 14, col: 12, color: '#3B8EA5' },
  { text: 'GUIDANCE', row: 20, col: 10, color: '#64748B' },
  { text: 'SECONDARY', row: 26, col: 6, color: '#334155' },
]

const glyphs = '@#+|=~-_. '

function generateGridRows(): string[][] {
  const rows: string[][] = []
  for (let r = 0; r < 40; r++) {
    const row: string[] = []
    for (let c = 0; c < 50; c++) {
      const term = highlightedTerms.find(
        (t) => r === t.row && c >= t.col && c < t.col + t.text.length
      )
      if (term) {
        row.push(`<span style="color:${term.color}">${term.text[c - term.col]}</span>`)
      } else {
        row.push(glyphs[Math.floor(Math.random() * glyphs.length)])
      }
    }
    rows.push(row)
  }
  return rows
}

export default function Audit() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const leftRef = useRef<HTMLDivElement>(null)
  const matrixRef = useRef<HTMLDivElement>(null)
  const [gridRows, setGridRows] = useState<string[][]>([])
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const initGrid = useCallback(() => {
    setGridRows(generateGridRows())
  }, [])

  useEffect(() => {
    initGrid()

    // Random character replacement
    intervalRef.current = setInterval(() => {
      setGridRows((prev) => {
        const newRows = prev.map((row) => [...row])
        const r = Math.floor(Math.random() * newRows.length)
        const c = Math.floor(Math.random() * newRows[0].length)
        const isHighlighted = highlightedTerms.some(
          (t) => r === t.row && c >= t.col && c < t.col + t.text.length
        )
        if (!isHighlighted) {
          const newChar = glyphs[Math.floor(Math.random() * glyphs.length)]
          newRows[r][c] = `<span style="color:#D4A03A">${newChar}</span>`
          // Fade back
          setTimeout(() => {
            setGridRows((current) => {
              const faded = current.map((row) => [...row])
              if (faded[r][c].includes('#D4A03A')) {
                faded[r][c] = newChar
              }
              return faded
            })
          }, 300)
        }
        return newRows
      })
    }, 200)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [initGrid])

  useEffect(() => {
    const left = leftRef.current
    const matrix = matrixRef.current
    if (!left || !matrix) return

    gsap.fromTo(
      left,
      { opacity: 0, x: -40 },
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      }
    )

    gsap.fromTo(
      matrix,
      { opacity: 0 },
      {
        opacity: 1,
        duration: 1,
        delay: 0.3,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  const gridContent = gridRows.map((row) => row.join('')).join('\n')

  return (
    <section
      id="audit"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <p className="section-label mb-6">05 — AUDIT & VALIDATION</p>

        {/* 3D Perspective Heading */}
        <PerspectiveHeading text="ZEROCRITICAL" revealedValue="ZERO CRITICAL" />

        <div className="flex flex-col lg:flex-row gap-12 mt-12">
          {/* Left side */}
          <div ref={leftRef} className="lg:w-1/2">
            <p className="text-base font-light text-[#64748B] leading-relaxed max-w-[440px] mb-8">
              Export is blocked until every paragraph carries source anchors, every quote matches stored spans, every authority resolves to verified text, and every chronology is internally consistent.
            </p>

            {/* Sample rules */}
            <div className="flex flex-col gap-3">
              {rules.map((rule, i) => (
                <div
                  key={i}
                  className="font-geist-mono text-xs text-[#64748B] py-2 px-3 rounded"
                  style={{
                    background: '#111D32',
                    border: '1px solid rgba(100, 116, 139, 0.1)',
                    borderLeft: '2px solid #E85D4C',
                  }}
                >
                  {rule}
                </div>
              ))}
            </div>

            {/* Authority hierarchy legend */}
            <div className="mt-8 flex flex-col gap-2">
              <p className="font-geist-mono text-[10px] uppercase tracking-[2px] text-[#64748B] mb-2">
                Authority Hierarchy
              </p>
              {[
                { label: 'Primary legislation in force', color: '#E2E8F0' },
                { label: 'Official procedural rules', color: '#D4A03A' },
                { label: 'Official case law', color: '#3B8EA5' },
                { label: 'Regulator guidance', color: '#64748B' },
                { label: 'Secondary commentary', color: '#334155' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full" style={{ background: item.color }} />
                  <span className="text-xs font-light text-[#64748B]">{item.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right side — ASCII Matrix */}
          <div ref={matrixRef} className="lg:w-1/2 relative">
            <div
              className="relative h-[400px] overflow-hidden rounded-lg"
              style={{
                background: '#0A1628',
                border: '1px solid rgba(100, 116, 139, 0.15)',
              }}
            >
              {/* Top fade */}
              <div
                className="absolute top-0 left-0 right-0 h-[60px] z-10 pointer-events-none"
                style={{ background: 'linear-gradient(to bottom, #0A1628, transparent)' }}
              />

              {/* Scrolling matrix */}
              <div className="ascii-matrix-scroll h-full overflow-hidden">
                <pre
                  className="font-geist-mono text-[11px] md:text-[13px] leading-[1.4] text-[#64748B] p-4"
                  style={{
                    animation: 'scrollUp 30s linear infinite',
                  }}
                  dangerouslySetInnerHTML={{ __html: gridContent + '\n' + gridContent }}
                />
              </div>

              {/* Bottom fade */}
              <div
                className="absolute bottom-0 left-0 right-0 h-[60px] z-10 pointer-events-none"
                style={{ background: 'linear-gradient(to top, #0A1628, transparent)' }}
              />
            </div>

            {/* Visually hidden description for accessibility */}
            <span className="sr-only">
              ASCII art visualization of the authority verification hierarchy showing five levels:
              Primary legislation in force, official procedural rules, official case law, regulator
              guidance, and secondary commentary. Characters scroll upward continuously with random
              glyph replacement animation.
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scrollUp {
          0% { transform: translateY(0); }
          100% { transform: translateY(-50%); }
        }
      `}</style>
    </section>
  )
}

function PerspectiveHeading({ text: _text, revealedValue }: { text: string; revealedValue: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = textRef.current
    if (!el) return

    const chars = el.querySelectorAll('span')
    chars.forEach((span, i) => {
      ;(span as HTMLElement).style.transitionDelay = `${i * 0.04}s`
    })

    const trigger = ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top 80%',
      end: 'top 30%',
      onEnter: () => el.classList.add('revealed'),
      onLeaveBack: () => el.classList.remove('revealed'),
    })

    return () => {
      trigger.kill()
    }
  }, [])

  const characters = revealedValue.split('')

  return (
    <div ref={containerRef} className="perspective-container flex items-center justify-center py-4">
      <div
        ref={textRef}
        className="rotate-text font-light uppercase tracking-[-2px] text-[#E2E8F0] text-center"
        style={{
          fontFamily: "'Geist', sans-serif",
          fontSize: 'clamp(36px, 6vw, 80px)',
          transformStyle: 'preserve-3d',
        }}
      >
        {characters.map((char, i) => (
          <span
            key={i}
            style={{
              display: char === ' ' ? 'inline' : 'inline-block',
              width: char === ' ' ? '0.4em' : undefined,
            }}
          >
            {char === ' ' ? '\u00A0' : char}
          </span>
        ))}
      </div>
    </div>
  )
}
