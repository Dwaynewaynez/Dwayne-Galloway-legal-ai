import { useEffect, useRef, useState, useCallback } from 'react'
import gsap from 'gsap'
import { Terminal, X, Send, Bot, User, ChevronRight, Sparkles, Volume2, Square } from 'lucide-react'
import { useTTS } from '../hooks/useTTS'

interface Message {
  id: string
  role: 'bot' | 'user'
  content: string
  sources?: { label: string; anchor: string }[]
  isTyping?: boolean
}

const knowledgeBase: Record<string, { content: string; sources?: { label: string; anchor: string }[] }> = {
  default: {
    content: `I am the FORENSIC system interpreter. I can break down any component of this deterministic evidence-controlled legal AI architecture.\n\nAsk me about:\n  • The five canonical layers and how they connect\n  • Why "no source, no fact" is the foundational principle\n  • How the Audit Engine blocks unsupported assertions\n  • The authority hierarchy (legislation > case law > guidance)\n  • Chronology integrity and date drift prevention\n  • How this differs from chatbot-style legal AI\n  • The phased implementation roadmap\n  • Any specific engine (Burden of Proof, Hallucination Detector, etc.)`,
  },
  greeting: {
    content: `FORENSIC System v1.0 — Deterministic Evidence Engine\nStatus: OPERATIONAL\n\nI maintain and explain every component of this litigation operating system. Every response I give will be anchored to specific architectural layers, principles, or documented rules.\n\nWhat would you like me to break down?`,
  },
  layers: {
    content: `The architecture consists of five canonical layers, each serving a distinct litigation function:\n\n【1】EVIDENCE VAULT\nImmutable storage for originals. SHA-256 hash on ingest. WORM (Write Once Read Many) storage. RFC 3161 timestamping. Chain of custody logging. Every transform creates a derivative record — originals are never overwritten.\n\n【2】FACT LEDGER\nConverts sources into atomic litigable facts. Each fact is single-purpose and source-bound. Allegations and opponent assertions are stored as separate predicates — never auto-promoted to proven facts. Uses PostgreSQL with JSONB for evidence metadata.\n\n【3】LEGAL MAPPING ENGINE\nMaps facts to legal elements and burdens. Versioned authorities with stale-guidance alerts. Example: CRA s11 (goods match description), EqA s29/s20/s21 (service provider duties + reasonable adjustments), UK GDPR Articles 22A-22D (automated decision-making).\n\n【4】DRAFTING ENGINE\nGenerates court-ready documents ONLY from controlled records. Paragraphs assembled from facts/events/issues. No paragraph may contain an unsourced factual clause. Templates enforce CPR/PD forms (WS, POC, LBA, skeleton arguments).\n\n【5】AUDIT ENGINE\nBlocks export until zero critical findings. Checks: source coverage, quote exactness, date coherence, pleading sufficiency, stale authorities, statement-of-truth placement, e-bundle linkability.`,
    sources: [
      { label: '§ Architecture', anchor: '#architecture' },
      { label: '§ Core Layers', anchor: '#engines' },
    ],
  },
  'no source no fact': {
    content: `"No source, no fact" is the foundational principle of this system. Here's what it means in practice:\n\nA document may generate a hypothesis, but NO proposition enters the pleaded narrative or witness evidence without a source anchor.\n\nEnforcement:\n  • Every fact carries: source_anchor (document + page + paragraph)\n  • Status field: asserted_by_source | proven | disputed | superseded\n  • Confidence is multidimensional (OCR confidence ≠ authority confidence ≠ causation confidence)\n  • The Hallucination Engine blocks any noun-date-verb proposition lacking an anchor\n  • Export is blocked until 100% source-anchor coverage is achieved\n\nThis directly addresses the Ayinde / Al-Haroun Divisional Court warning about AI-generated false citations and unchecked output.`,
    sources: [
      { label: '§ Principles', anchor: '#principles' },
      { label: '§ Audit Engine', anchor: '#audit' },
    ],
  },
  audit: {
    content: `The Audit Engine is the final gate before any court-facing document can be exported. It operates as a deterministic rule-checker, not a probabilistic filter.\n\nCritical checks (export blocked if any fail):\n  ✓ Every factual assertion resolves to a source anchor\n  ✓ Every quote matches stored spans byte-for-byte\n  ✓ Every legal authority resolves to verified text (neutral citation or official case link)\n  ✓ Chronology is internally consistent (no date contradictions within paragraphs)\n  ✓ No stale authorities (guidance flagged if statute has been amended)\n  ✓ Statement of truth placed correctly per document type\n  ✓ E-bundle links resolve (every exhibit mention resolves to exact document + page)\n\nDocument-type specific checks:\n  • Witness Statements: first person, own words, personal knowledge only (PD 32/PD 57AC)\n  • Particulars of Claim: concise facts, remedy specified, interest basis (CPR Part 16/PD 16)\n  • Bundles: OCR, hyperlinks, bookmarks, sequential pagination`,
    sources: [
      { label: '§ Audit & Validation', anchor: '#audit' },
      { label: '§ Core Layers', anchor: '#engines' },
    ],
  },
  authority: {
    content: `The authority hierarchy prevents the most common legal AI failure: treating stale guidance as binding law.\n\nPriority stack (highest to lowest):\n\n  ★★★★★  Primary legislation in force\n           legislation.gov.uk Acts, Regulations, UK GDPR text\n           Checked: jurisdiction, commencement, amendment status, date-in-force\n\n  ★★★★☆  Official procedural rules\n           CPR Parts and Practice Directions on Justice UK\n           Checked: current version, court applicability\n\n  ★★★★☆  Official case law\n           Find Case Law / National Archives neutral citation\n           Checked: neutral citation, court level, treatment date\n\n  ★★★☆☆  Official regulator handbooks/guidance\n           FCA Handbook, ICO, NCSC, CPS, MoJ policy\n           Checked: publication date, whether guidance or binding rule, STALENESS\n\n  ★★☆☆☆  Party/institutional records\n           Letters, call notes, policies, SAR files\n           Checked: authenticity, metadata, provenance, privilege\n\n  ★☆☆☆☆  Secondary commentary\n           Textbooks, blogs, journal notes\n           Always flagged as secondary — never default authority\n\nKey example: As of June 2026, legislation.gov.uk shows UK GDPR Articles 22A-22D (introduced by Data (Use and Access) Act 2025), while some ICO guidance still discusses the older Article 22 framework. The system shows statute as controlling and flags older guidance as stale.`,
    sources: [
      { label: '§ Authority Engine', anchor: '#engines' },
      { label: '§ Audit & Validation', anchor: '#audit' },
    ],
  },
  chronology: {
    content: `Chronology integrity is foundational because legal narratives most often fail through date drift — merged events, timezone slips, or corrupted date order.\n\nEach event holds multiple date fields:\n  • document_date — date on the document itself\n  • event_date — when the event actually occurred\n  • sent_date — when correspondence was sent\n  • received_date — when correspondence was received\n  • decision_date — for decisions/rulings\n  • deadline_date — for procedural deadlines\n  • date_confidence — high | medium | low | uncertain\n\nDate precedence rules (deterministic):\n  1. explicit_event_date (if stated in text)\n  2. sent_date (if document is correspondence)\n  3. decision_date (if document is a decision)\n  4. document_date (fallback)\n\nOn conflict: record alternatives, set date_confidence = low, prohibit strong date language.\n\nPD 32 requires chronological witness evidence. JR pleadings must contain all material facts after proper inquiry. The system enforces both.`,
    sources: [
      { label: '§ Principles', anchor: '#principles' },
      { label: '§ Core Layers', anchor: '#engines' },
    ],
  },
  'vs chatbot': {
    content: `This system is fundamentally different from conversational legal AI assistants:\n\nCHATBOT-STYLE AI:\n  • Success criterion: plausible-sounding language\n  • Output: conversational answers, summaries\n  • Sources: may cite, may not — no enforcement\n  • Hallucination: common, hard to detect\n  • Court-ready: No — requires full manual rewrite\n  • Audit trail: None\n\nDETERMINISTIC FORENSIC AI (this system):\n  • Success criterion: every fact traceable to source\n  • Output: bundle-ready chronologies, witness statements, particulars of claim, skeleton arguments with hyperlinked source anchors\n  • Sources: mandatory — no source, no fact, export blocked\n  • Hallucination: blocked by Audit Engine — unsupported assertions fail export\n  • Court-ready: Yes — CPR/PD compliant templates, statements of truth, e-bundle format\n  • Audit trail: Full W3C PROV provenance graph, SHA-256 hashes, RFC 3161 timestamps\n\nThe Divisional Court in Ayinde / Al-Haroun explicitly warned about unchecked AI-generated output. This system is designed to never produce that.`,
    sources: [
      { label: '§ Principles', anchor: '#principles' },
      { label: '§ Audit Engine', anchor: '#audit' },
    ],
  },
  engines: {
    content: `The system includes 14+ specialized forensic engines operating over the same controlled ledger:\n\nEVIDENTIAL REASONING:\n  • Burden of Proof — tracks who must prove what, to what standard\n  • Admission Engine — isolates express/implied admissions from correspondence\n  • Evidence Weighting — ranks proof strength without collapsing into one score\n  • Reliability Engine — models source dependability from metadata/custody\n  • Corroboration Engine — detects genuine support vs copied repetition\n  • Silence Analysis — treats non-response as legal signal only when rules permit\n\nANTI-HALLUCINATION:\n  • Chronology Integrity — prevents date drift and event conflation\n  • Quote Preservation — exact text from stored spans only\n  • Hallucination Detector — blocks unsupported noun-date-verb propositions\n  • Truth Maintenance — keeps accepted/disputed/superseded facts coherent\n  • Confidence Separation — multidimensional vectors, never one scalar\n\nLEGAL/PROCEDURAL:\n  • Legal Authority Engine — resolves statutes/cases to current authoritative text\n  • Procedural Engine — computes deadlines (SAR: 1 month, JR reply: 7 days)\n  • Bundle Intelligence — produces hearing bundle structures with hyperlink indices\n\nADVERSARIAL/STRATEGIC:\n  • Contradiction Ranking — by materiality, source quality, directness, timing\n  • Judge Mode — strips rhetoric, surfaces material facts/law/remedy\n  • Red/Blue/Grey Team — stress-tests from all three perspectives`,
    sources: [
      { label: '§ Engines', anchor: '#engines' },
    ],
  },
  implementation: {
    content: `The recommended implementation follows six phases, total 42-62 weeks:\n\nPhase 1 — Discovery (4-6 weeks)\n  Matter taxonomy, jurisdiction profiles, source hierarchy, UK rule packs\n\nPhase 2 — Core Vault & Ledger (8-10 weeks)\n  Immutable vault, ingestion pipeline, hashing/timestamping, PostgreSQL ledger,\n  basic OCR/text extraction, authentication\n  Exit: deterministic ingest of sample corpus; audit trail complete\n\nPhase 3 — Chronology & Intelligence (8-12 weeks)\n  Classifiers, date extraction, entity resolution, chronology engine,\n  source anchors, search UI\n  Exit: golden-set chronology accuracy accepted\n\nPhase 4 — Legal Mapping & Disclosure (8-12 weeks)\n  Authority engine, element maps, gap/disclosure engines, contradiction\n  and admission engines\n  Exit: no unsupported authorities in test drafts\n\nPhase 5 — Drafting & Bundles (8-10 weeks)\n  WS, POC, LBA, skeleton templates; source-linked export; e-bundle builder\n  Exit: bundle passes hyperlink/pagination/OCR checks\n\nPhase 6 — Audit & Pilot (6-12 weeks)\n  Full audit engine, hallucination detector, transparency log,\n  red/blue/grey review workflows, lawyer training\n  Exit: pilot matters completed without critical audit escape`,
    sources: [
      { label: '§ Implementation', anchor: '#timeline' },
    ],
  },
  'burden of proof': {
    content: `The Burden of Proof engine tracks who must prove what, and to what standard, for each legal element in a matter.\n\nKey rules:\n  • Claimant proves pleaded facts (standard: balance of probabilities for civil)\n  • EqA s136 burden shift: triggered ONLY when primary facts capable of supporting discrimination are recorded in the Fact Ledger\n  • The burden is never assumed shifted — the system requires the triggering facts to be explicitly present\n\nData model:\n  BurdenRecord { issue, element, bearer, standard, satisfied_by[] }\n\nEvery burden state change is logged with the triggering fact IDs, so the reasoning can be reconstructed during audit or challenged in proceedings.`,
    sources: [
      { label: '§ Engines', anchor: '#engines' },
    ],
  },
  'hallucination detector': {
    content: `The Hallucination Detector is the last line of defense before export. It performs claim extraction + anchor resolution on every paragraph.\n\nHow it works:\n  1. Extract noun-date-verb propositions from draft text\n  2. Resolve each claim against the Fact Ledger\n  3. If claim.is_factual AND NOT ledger.supports(claim) → CRITICAL finding\n  4. If claim.is_quote AND NOT ledger.quote_matches(claim) → CRITICAL finding\n  5. If claim.is_legal AND NOT authorities.supports(claim) → CRITICAL finding\n  6. If chronology.is_inconsistent_with(para) → MAJOR finding\n\nExport is BLOCKED while any CRITICAL finding exists.\n\nThis is not a confidence score or probability — it is a deterministic pass/fail gate. Every finding carries a paragraph_ref, rule_id, explanation, and fix_hint.`,
    sources: [
      { label: '§ Audit Engine', anchor: '#audit' },
      { label: '§ Engines', anchor: '#engines' },
    ],
  },
  'quote preservation': {
    content: `Quote Preservation ensures legally significant wording is preserved exactly.\n\nRules:\n  • Quotes are copied ONLY from stored spans in the Evidence Vault\n  • Each Quote record: { id, exact_text, char_offsets, page_ref }\n  • Any edit to a quote breaks its cryptographic signature and fails audit\n  • If source is OCR, manual_verify flag is required\n\nAudit check (QUOTE_EXACTNESS rule):\n  when: draft_contains_quote = true\n  then: resolve_quote_to_source_span = REQUIRED\n        compare_text = byte_exact_after_normalisation\n  fail_severity: critical\n  exception: if_source_is_ocr → require_manual_verify = true\n\nThis prevents the common failure mode where a "close enough" paraphrase changes legal meaning.`,
    sources: [
      { label: '§ Engines', anchor: '#engines' },
      { label: '§ Audit', anchor: '#audit' },
    ],
  },
  'data model': {
    content: `The data model uses a W3C PROV-style provenance graph:\n\nCore entities:\n  MATTER → contains → DOCUMENT\n  DOCUMENT → yields → EXTRACT (via parsing)\n  EXTRACT → has → HASH_RECORD + OCR_VERSION\n  EXTRACT → instantiates → FACT\n  FACT → relevant_to → EVENT, ISSUE\n  ISSUE → mapped_by → AUTHORITY\n  AUTHORITY → cites → (other authorities)\n  FACT → supports → DRAFT_PARAGRAPH\n  DRAFT → checked_by → AUDIT_FINDING\n  DRAFT → versioned_as → VERSION\n  DOCUMENT → tracked_by → CHAIN_OF_CUSTODY_ENTRY\n\nKey design decisions:\n  • Facts are superseded, not overwritten (event sourcing)\n  • Every transform creates a provenance record\n  • Canonical JSON (RFC 8785) for hashable, deterministic serialization\n  • SHA-256 digests + RFC 3161 timestamps for signable records\n  • Append-only transparency / Merkle logging for critical artefacts`,
    sources: [
      { label: '§ Architecture', anchor: '#architecture' },
    ],
  },
  security: {
    content: `Security controls for UK legal work:\n\nACCESS CONTROL:\n  • Zero-trust service-to-service auth\n  • Per-matter RBAC/ABAC\n  • Privileged and special-category data segregated from ingestion\n  • Row-level security in PostgreSQL\n\nDATA PROTECTION:\n  • Matter-based isolation (each matter is a separate security boundary)\n  • Per-document ACLs\n  • Envelope encryption with per-matter keys\n  • DLP scanning on export\n  • Secure redaction workflows\n\nAUDIT & INTEGRITY:\n  • Tamper-evident audit logging\n  • Immutable originals (WORM storage)\n  • Signed build manifests for every export\n  • Model egress controls (no data leaves the system boundary without audit)\n  • Searchable, access-controlled logs for every evidence access/transform/export/deletion\n\nCOMPLIANCE:\n  • UK GDPR: appropriate technical and organisational measures\n  • ICO SAR guidance: secure disclosure, reasonable/proportionate retrieval\n  • NCSC guidance: logging as foundational to retrospective investigation\n  • CPS digital-material guidance: logging of seized/imaged material`,
    sources: [
      { label: '§ Architecture', anchor: '#architecture' },
    ],
  },
}

function findBestResponse(input: string): { content: string; sources?: { label: string; anchor: string }[] } {
  const lower = input.toLowerCase().trim()

  // Direct keyword matching
  if (lower.match(/^(hi|hello|hey|start|help)$/)) return knowledgeBase.greeting
  if (lower.includes('layer') || lower.includes('architecture') || lower.includes('five') || lower.includes('5')) return knowledgeBase.layers
  if (lower.includes('no source') || lower.includes('source') || lower.includes('principle') || lower.includes('foundation')) return knowledgeBase['no source no fact']
  if (lower.includes('audit') || lower.includes('block') || lower.includes('export') || lower.includes('gate') || lower.includes('check')) return knowledgeBase.audit
  if (lower.includes('authority') || lower.includes('hierarchy') || lower.includes('legislation') || lower.includes('guidance') || lower.includes('stale')) return knowledgeBase.authority
  if (lower.includes('chronolog') || lower.includes('date') || lower.includes('timeline') || lower.includes('drift')) return knowledgeBase.chronology
  if (lower.includes('chatbot') || lower.includes('vs') || lower.includes('versus') || lower.includes('difference') || lower.includes('plausible') || lower.includes('language')) return knowledgeBase['vs chatbot']
  if (lower.includes('engine') || lower.includes('all engine')) return knowledgeBase.engines
  if (lower.includes('implement') || lower.includes('phase') || lower.includes('roadmap') || lower.includes('timeline') || lower.includes('deploy')) return knowledgeBase.implementation
  if (lower.includes('burden') || lower.includes('proof') || lower.includes('shift')) return knowledgeBase['burden of proof']
  if (lower.includes('hallucinat') || lower.includes('detect') || lower.includes('false') || lower.includes('fake')) return knowledgeBase['hallucination detector']
  if (lower.includes('quote') || lower.includes('exact') || lower.includes('wording') || lower.includes('paraphrase')) return knowledgeBase['quote preservation']
  if (lower.includes('data model') || lower.includes('schema') || lower.includes('entity') || lower.includes('prov') || lower.includes('graph')) return knowledgeBase['data model']
  if (lower.includes('security') || lower.includes('privacy') || lower.includes('gdpr') || lower.includes('access') || lower.includes('encrypt')) return knowledgeBase.security

  // Partial matching for engine names
  if (lower.includes('judge')) return { content: `**Judge Mode** converts material into what a judge needs fastest. It strips rhetoric, surfaces material facts/law/remedy, and produces an issues list with missing-link reports. This is particularly valuable because CPR Part 16 and PD 16 reward concise pleading, not maximal narrative volume.\n\nJudge Mode output format:\n  1. Issues list (numbered, with legal elements)\n  2. Essential facts per issue\n  3. Missing links (facts needed but not yet proved)\n  4. Authorities required per issue\n  5. Recommended remedies with legal basis`, sources: [{ label: '§ Engines', anchor: '#engines' }] }
  if (lower.includes('contradiction') || lower.includes('conflict')) return { content: `**Contradiction Ranking** prioritises contradictions by:\n  • Materiality to legal element\n  • Source quality (contemporaneous business record > later unsupported assertion)\n  • Directness (first-hand > hearsay)\n  • Timing (earlier > later for establishing facts)\n\nThe engine stores every contradiction with fact_a, fact_b, materiality_score, and source_strength. Contradictions are surfaced in the chronology view and drive the Question Generator for cross-examination and Part 18 requests.`, sources: [{ label: '§ Engines', anchor: '#engines' }] }
  if (lower.includes('procedural') || lower.includes('deadline') || lower.includes('sar') || lower.includes('jr ')) return { content: `**Procedural Engine** computes all deadlines from chronology + court profile. Examples:\n  • SAR response: 1 month from receipt\n  • JR reply: 7 days\n  • Ombudsman referral: after final response or elapsed time\n  • Pre-action protocol deadlines\n\nEvery deadline carries its legal source (statute + section), and the system logs expected actions. Silence (non-response by deadline) is logged as a legal signal — but only treated as deemed admission when the specific rule permits.`, sources: [{ label: '§ Engines', anchor: '#engines' }] }
  if (lower.includes('admission')) return { content: `**Admission Engine** isolates express or implied admissions from letters, emails, call notes, and defences.\n\nFlagged patterns:\n  • "We will take no further action"\n  • "Your account has been restricted"\n  • "No record exists" → later becomes "Recording unavailable" (narrative mutation flagged)\n  • Notices to admit facts/documents\n\nEach admission stores: exact source span, actor, date, category (express/implied), and legal_effect. Privilege filter applied before extraction.`, sources: [{ label: '§ Engines', anchor: '#engines' }] }

  return {
    content: `I don't have a specific entry for that query. Let me give you the system overview:\n\n${knowledgeBase.layers.content}\n\nTry asking about specific topics like "audit engine", "authority hierarchy", "chronology integrity", "burden of proof", or "how this differs from chatbots".`,
    sources: [{ label: '§ Architecture', anchor: '#architecture' }],
  }
}

const suggestedPrompts = [
  'Explain the 5 layers',
  'How does the Audit Engine work?',
  'Authority hierarchy',
  'Chronology integrity',
  'How is this different from chatbots?',
  'Hallucination detection',
]

export default function MachineBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const { speak, stop, isSpeaking } = useTTS()

  // Initial greeting when opened
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      addBotMessage(knowledgeBase.greeting.content)
    }
  }, [isOpen])

  const addBotMessage = useCallback((content: string, sources?: { label: string; anchor: string }[]) => {
    setIsTyping(true)
    const id = `msg-${Date.now()}`

    // Add typing indicator
    setMessages((prev) => [...prev, { id, role: 'bot', content: '', sources, isTyping: true }])

    // Simulate typing delay based on content length
    const delay = Math.min(800 + content.length * 8, 3000)

    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === id ? { ...m, content, isTyping: false } : m))
      )
      setIsTyping(false)
    }, delay)
  }, [])

  const handleSend = useCallback(() => {
    const text = input.trim()
    if (!text || isTyping) return

    // Add user message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
    }
    setMessages((prev) => [...prev, userMsg])
    setInput('')

    // Find and send response
    const response = findBestResponse(text)
    setTimeout(() => {
      addBotMessage(response.content, response.sources)
    }, 400)
  }, [input, isTyping, addBotMessage])

  const handlePromptClick = useCallback(
    (prompt: string) => {
      if (isTyping) return
      const userMsg: Message = {
        id: `user-${Date.now()}`,
        role: 'user',
        content: prompt,
      }
      setMessages((prev) => [...prev, userMsg])

      const response = findBestResponse(prompt)
      setTimeout(() => {
        addBotMessage(response.content, response.sources)
      }, 400)
    },
    [isTyping, addBotMessage]
  )

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  // Animate panel open/close
  useEffect(() => {
    if (panelRef.current) {
      if (isOpen) {
        gsap.fromTo(
          panelRef.current,
          { opacity: 0, x: 40, scale: 0.95 },
          { opacity: 1, x: 0, scale: 1, duration: 0.4, ease: 'power3.out' }
        )
      }
    }
  }, [isOpen])

  return (
    <>
      {/* Floating Trigger Button */}
      <button
        ref={triggerRef}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-[60] w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
        style={{
          background: isOpen ? '#64748B' : '#E85D4C',
          boxShadow: isOpen
            ? '0 4px 20px rgba(100, 116, 139, 0.3)'
            : '0 4px 20px rgba(232, 93, 76, 0.4)',
        }}
        aria-label={isOpen ? 'Close system bot' : 'Open system bot'}
      >
        {isOpen ? <X size={20} color="#E2E8F0" /> : <Terminal size={20} color="#0A1628" />}
      </button>

      {/* Chat Panel */}
      {isOpen && (
        <div
          ref={panelRef}
          className="fixed bottom-24 right-6 z-[60] w-[380px] max-w-[calc(100vw-48px)] flex flex-col"
          style={{
            height: '560px',
            maxHeight: 'calc(100vh - 140px)',
            background: '#0F1D30',
            border: '1px solid rgba(100, 116, 139, 0.2)',
            borderRadius: '12px',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(100, 116, 139, 0.1)',
            overflow: 'hidden',
          }}
        >
          {/* Header */}
          <div
            className="flex items-center gap-3 px-4 py-3 flex-shrink-0"
            style={{
              background: '#111D32',
              borderBottom: '1px solid rgba(100, 116, 139, 0.15)',
            }}
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(232, 93, 76, 0.15)' }}
            >
              <Bot size={16} color="#E85D4C" />
            </div>
            <div className="flex-1">
              <p className="font-geist-mono text-xs tracking-[1px] text-[#E2E8F0] uppercase">
                System Interpreter
              </p>
              <p className="font-geist-mono text-[10px] text-[#64748B]">v1.0 — Deterministic</p>
            </div>
            <div className="flex items-center gap-1.5">
              <div
                className="w-1.5 h-1.5 rounded-full"
                style={{
                  background: '#3B8EA5',
                  boxShadow: '0 0 6px rgba(59, 142, 165, 0.6)',
                }}
              />
              <span className="font-geist-mono text-[10px] text-[#3B8EA5]">ONLINE</span>
            </div>
          </div>

          {/* Messages Area */}
          <div
            className="flex-1 overflow-y-auto px-4 py-3"
            style={{ scrollbarWidth: 'thin', scrollbarColor: '#1A2744 transparent' }}
          >
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Terminal size={32} color="#64748B" opacity={0.5} className="mb-3" />
                <p className="font-geist-mono text-xs text-[#64748B]">
                  Initialising system interpreter...
                </p>
              </div>
            )}

            {messages.map((msg) => (
              <div key={msg.id} className={`mb-4 ${msg.role === 'user' ? 'ml-8' : 'mr-4'}`}>
                {/* Avatar + Name */}
                <div className="flex items-center gap-2 mb-1.5">
                  {msg.role === 'bot' ? (
                    <>
                      <Bot size={12} color="#E85D4C" />
                      <span className="font-geist-mono text-[10px] uppercase tracking-[1px] text-[#E85D4C]">
                        System
                      </span>
                      {!msg.isTyping && msg.content && (
                        <button
                          onClick={() => {
                            if (isSpeaking) stop()
                            else speak(msg.content.replace(/[【】]/g, ''))
                          }}
                          className="ml-1.5 p-0.5 rounded transition-colors duration-200 hover:bg-[#E85D4C20]"
                          title={isSpeaking ? 'Stop speaking' : 'Read aloud'}
                        >
                          {isSpeaking ? (
                            <Square size={8} color="#E85D4C" />
                          ) : (
                            <Volume2 size={8} color="#64748B" />
                          )}
                        </button>
                      )}
                    </>
                  ) : (
                    <>
                      <User size={12} color="#3B8EA5" />
                      <span className="font-geist-mono text-[10px] uppercase tracking-[1px] text-[#3B8EA5]">
                        Operator
                      </span>
                    </>
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className="rounded-lg px-3.5 py-2.5"
                  style={{
                    background:
                      msg.role === 'bot' ? 'rgba(100, 116, 139, 0.08)' : 'rgba(59, 142, 165, 0.08)',
                    border:
                      msg.role === 'bot'
                        ? '1px solid rgba(100, 116, 139, 0.12)'
                        : '1px solid rgba(59, 142, 165, 0.12)',
                  }}
                >
                  {msg.isTyping ? (
                    <div className="flex items-center gap-1.5 py-1">
                      <div
                        className="w-1.5 h-1.5 rounded-full bg-[#E85D4C] animate-pulse"
                        style={{ animationDelay: '0ms' }}
                      />
                      <div
                        className="w-1.5 h-1.5 rounded-full bg-[#E85D4C] animate-pulse"
                        style={{ animationDelay: '150ms' }}
                      />
                      <div
                        className="w-1.5 h-1.5 rounded-full bg-[#E85D4C] animate-pulse"
                        style={{ animationDelay: '300ms' }}
                      />
                      <span className="font-geist-mono text-[10px] text-[#64748B] ml-1">
                        Processing...
                      </span>
                    </div>
                  ) : (
                    <div className="font-geist-mono text-[12px] text-[#E2E8F0] leading-[1.7] whitespace-pre-wrap">
                      {formatMessageContent(msg.content)}
                    </div>
                  )}
                </div>

                {/* Sources */}
                {msg.sources && msg.sources.length > 0 && !msg.isTyping && (
                  <div className="flex items-center gap-2 mt-2 ml-1">
                    <Sparkles size={10} color="#64748B" />
                    <div className="flex gap-2">
                      {msg.sources.map((src, i) => (
                        <a
                          key={i}
                          href={src.anchor}
                          onClick={(e) => {
                            e.preventDefault()
                            const target = document.querySelector(src.anchor)
                            if (target) target.scrollIntoView({ behavior: 'smooth' })
                            setIsOpen(false)
                          }}
                          className="font-geist-mono text-[10px] text-[#3B8EA5] hover:text-[#E85D4C] transition-colors duration-200 flex items-center gap-0.5"
                        >
                          <ChevronRight size={8} />
                          {src.label}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Prompts */}
          {messages.length <= 2 && (
            <div
              className="px-4 pb-2 flex-shrink-0"
              style={{ borderTop: '1px solid rgba(100, 116, 139, 0.08)' }}
            >
              <p className="font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] mt-2 mb-1.5">
                Suggested queries
              </p>
              <div className="flex flex-wrap gap-1.5 pb-2">
                {suggestedPrompts.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handlePromptClick(prompt)}
                    className="font-geist-mono text-[10px] px-2.5 py-1 rounded transition-all duration-200 hover:scale-[1.02]"
                    style={{
                      background: 'rgba(100, 116, 139, 0.1)',
                      color: '#64748B',
                      border: '1px solid rgba(100, 116, 139, 0.15)',
                    }}
                    onMouseEnter={(e) => {
                      const el = e.currentTarget
                      el.style.background = 'rgba(232, 93, 76, 0.1)'
                      el.style.color = '#E85D4C'
                      el.style.borderColor = 'rgba(232, 93, 76, 0.2)'
                    }}
                    onMouseLeave={(e) => {
                      const el = e.currentTarget
                      el.style.background = 'rgba(100, 116, 139, 0.1)'
                      el.style.color = '#64748B'
                      el.style.borderColor = 'rgba(100, 116, 139, 0.15)'
                    }}
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input Area */}
          <div
            className="px-3 py-3 flex-shrink-0 flex items-center gap-2"
            style={{
              background: '#111D32',
              borderTop: '1px solid rgba(100, 116, 139, 0.15)',
            }}
          >
            <span className="font-geist-mono text-xs text-[#E85D4C] flex-shrink-0">&gt;</span>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend()
              }}
              placeholder="Query the system..."
              className="flex-1 bg-transparent font-geist-mono text-xs text-[#E2E8F0] placeholder-[#64748B] outline-none"
              style={{ caretColor: '#E85D4C' }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="w-7 h-7 rounded flex items-center justify-center transition-all duration-200 flex-shrink-0"
              style={{
                background: input.trim() && !isTyping ? 'rgba(232, 93, 76, 0.15)' : 'transparent',
                opacity: input.trim() && !isTyping ? 1 : 0.3,
              }}
            >
              <Send size={12} color="#E85D4C" />
            </button>
          </div>
        </div>
      )}
    </>
  )
}

// Format message content with styled markers
function formatMessageContent(content: string) {
  // Replace 【 markers with styled spans
  const parts = content.split(/(\【\d+\】)/g)
  return parts.map((part, i) => {
    if (part.match(/\【\d+\】/)) {
      return (
        <span key={i} className="text-[#E85D4C] font-medium">
          {part}
        </span>
      )
    }
    // Highlight specific patterns
    const withHighlights = part
      .split(/(EVIDENCE VAULT|FACT LEDGER|LEGAL MAPPING|DRAFTING ENGINE|AUDIT ENGINE)/g)
      .map((sub, j) =>
        sub.match(/EVIDENCE VAULT|FACT LEDGER|LEGAL MAPPING|DRAFTING ENGINE|AUDIT ENGINE/) ? (
          <span key={`${i}-${j}`} className="text-[#D4A03A] font-medium">
            {sub}
          </span>
        ) : (
          sub
        )
      )
    return <span key={i}>{withHighlights}</span>
  })
}
