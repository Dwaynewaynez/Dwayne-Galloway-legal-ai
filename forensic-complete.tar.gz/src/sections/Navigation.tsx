import { useEffect, useRef, useState } from 'react'

const navLinks = [
  { label: 'Vault', href: '#vault' },
  { label: 'Principles', href: '#principles' },
  { label: 'Architecture', href: '#architecture' },
  { label: 'Engines', href: '#engines' },
  { label: 'Audit', href: '#audit' },
  { label: 'Contact', href: '#contact' },
]

export default function Navigation() {
  const navRef = useRef<HTMLElement>(null)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    if (navRef.current) {
      navRef.current.style.opacity = '0'
      navRef.current.style.transition = 'opacity 0.6s ease'
      const timer = setTimeout(() => {
        if (navRef.current) {
          navRef.current.style.opacity = '1'
        }
      }, 200)
      return () => clearTimeout(timer)
    }
  }, [])

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    setMobileOpen(false)
    const target = document.querySelector(href)
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-50 h-14 flex items-center justify-between px-6 md:px-12"
      style={{
        background: 'rgba(10, 22, 40, 0.92)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(100, 116, 139, 0.15)',
      }}
    >
      <a
        href="#"
        className="font-geist-mono text-sm tracking-[4px] text-[#E2E8F0] hover:text-[#E85D4C] transition-colors duration-300"
        onClick={(e) => {
          e.preventDefault()
          window.scrollTo({ top: 0, behavior: 'smooth' })
        }}
      >
        FORENSIC
      </a>

      {/* Desktop Nav */}
      <div className="hidden md:flex items-center gap-8">
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleClick(e, link.href)}
            className="font-geist-mono text-[11px] uppercase tracking-[2px] text-[#64748B] hover:text-[#E85D4C] transition-colors duration-300"
          >
            {link.label}
          </a>
        ))}
      </div>

      {/* Mobile Hamburger */}
      <button
        className="md:hidden flex flex-col gap-1.5 p-2"
        onClick={() => setMobileOpen(!mobileOpen)}
        aria-label="Toggle menu"
      >
        <span
          className="block w-5 h-px bg-[#E2E8F0] transition-transform duration-300"
          style={{
            transform: mobileOpen ? 'rotate(45deg) translate(2px, 2px)' : 'none',
          }}
        />
        <span
          className="block w-5 h-px bg-[#E2E8F0] transition-opacity duration-300"
          style={{ opacity: mobileOpen ? 0 : 1 }}
        />
        <span
          className="block w-5 h-px bg-[#E2E8F0] transition-transform duration-300"
          style={{
            transform: mobileOpen ? 'rotate(-45deg) translate(2px, -2px)' : 'none',
          }}
        />
      </button>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="absolute top-14 left-0 right-0 md:hidden flex flex-col items-center gap-6 py-8"
          style={{
            background: 'rgba(10, 22, 40, 0.98)',
            backdropFilter: 'blur(12px)',
            borderBottom: '1px solid rgba(100, 116, 139, 0.15)',
          }}
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleClick(e, link.href)}
              className="font-geist-mono text-xs uppercase tracking-[2px] text-[#64748B] hover:text-[#E85D4C] transition-colors duration-300"
            >
              {link.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  )
}
