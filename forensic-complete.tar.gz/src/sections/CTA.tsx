import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

export default function CTA() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const buttonsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const heading = headingRef.current
    const buttons = buttonsRef.current
    if (!heading || !buttons) return

    gsap.fromTo(
      heading,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      }
    )

    gsap.fromTo(
      buttons,
      { opacity: 0, y: 20 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        delay: 0.4,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="w-full py-24 md:py-32"
      style={{
        background: 'linear-gradient(to bottom, #0A1628, #111D32)',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 text-center">
        <h2
          ref={headingRef}
          className="text-[36px] md:text-[56px] font-light leading-[1.1] text-[#E2E8F0] mb-6"
          style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}
        >
          Start with evidence. End with truth.
        </h2>
        <p className="text-base md:text-lg font-light text-[#64748B] max-w-[560px] mx-auto leading-relaxed mb-10">
          Deploy a litigation operating system where every factual proposition can be traced back to its source, re-run, audited, and reproduced.
        </p>

        <div ref={buttonsRef} className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            className="font-geist-mono text-xs uppercase tracking-[2px] px-10 py-4 rounded-md transition-colors duration-300"
            style={{
              background: '#E85D4C',
              color: '#0A1628',
            }}
            onMouseEnter={(e) => {
              ;(e.currentTarget as HTMLElement).style.background = '#FF7A6B'
            }}
            onMouseLeave={(e) => {
              ;(e.currentTarget as HTMLElement).style.background = '#E85D4C'
            }}
          >
            Request a Demonstration
          </button>

          <a
            href="#"
            className="font-geist-mono text-xs uppercase tracking-[2px] px-10 py-4 rounded-md transition-all duration-300"
            style={{
              background: 'transparent',
              border: '1px solid rgba(100, 116, 139, 0.3)',
              color: '#64748B',
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget as HTMLElement
              el.style.borderColor = '#3B8EA5'
              el.style.color = '#3B8EA5'
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget as HTMLElement
              el.style.borderColor = 'rgba(100, 116, 139, 0.3)'
              el.style.color = '#64748B'
            }}
          >
            Read the Technical Paper →
          </a>
        </div>
      </div>
    </section>
  )
}
