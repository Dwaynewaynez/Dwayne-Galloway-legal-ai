import { useState, useRef, useCallback, useEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import {
  Upload,
  FileText,
  FileImage,
  FileSpreadsheet,
  Mail,
  X,
  CheckCircle2,
  Clock,
  Loader2,
  Shield,
  Hash,
  Search,
  Calendar,
  AlertTriangle,
  Link2,
  ChevronDown,
  ChevronUp,
  Volume2,
} from 'lucide-react'
import { useTTS } from '../hooks/useTTS'

interface UploadedDoc {
  id: string
  name: string
  type: string
  size: string
  status: 'queued' | 'hashing' | 'vault' | 'ocr' | 'extracting' | 'classified' | 'ledger' | 'complete'
  hash: string
  facts: ExtractedFact[]
  progress: number
}

interface ExtractedFact {
  id: string
  predicate: string
  subject: string
  date: string
  source: string
  confidence: 'high' | 'medium' | 'low'
  status: 'asserted' | 'verified' | 'disputed'
}

const mockFacts: ExtractedFact[] = [
  { id: 'F001', predicate: 'account_restriction', subject: 'Claimant', date: '2025-01-03', source: 'p1 ¶2', confidence: 'high', status: 'verified' },
  { id: 'F002', predicate: 'complaint_acknowledged', subject: 'Defendant', date: '2025-01-10', source: 'p1 ¶1', confidence: 'high', status: 'verified' },
  { id: 'F003', predicate: 'admission_no_action', subject: 'Adviser', date: '2025-02-14', source: 'p3 ¶4', confidence: 'high', status: 'asserted' },
  { id: 'F004', predicate: 'sar_submitted', subject: 'Claimant', date: '2025-03-01', source: 'p1 ¶1', confidence: 'high', status: 'verified' },
  { id: 'F005', predicate: 'sar_response_missing_recording', subject: 'Defendant', date: '2025-04-02', source: 'p1 ¶1', confidence: 'medium', status: 'asserted' },
  { id: 'F006', predicate: 'final_response_issued', subject: 'Defendant', date: '2025-05-20', source: 'p1', confidence: 'high', status: 'verified' },
  { id: 'F007', predicate: 'pre_action_letter_sent', subject: 'Claimant', date: '2025-06-01', source: 'p1 ¶1', confidence: 'high', status: 'verified' },
]

const statusLabels: Record<string, { label: string; color: string }> = {
  queued: { label: 'Queued', color: '#64748B' },
  hashing: { label: 'Computing SHA-256...', color: '#D4A03A' },
  vault: { label: 'Stored in Vault', color: '#3B8EA5' },
  ocr: { label: 'OCR / Text extraction...', color: '#D4A03A' },
  extracting: { label: 'Extracting facts...', color: '#D4A03A' },
  classified: { label: 'Classified', color: '#3B8EA5' },
  ledger: { label: 'In Fact Ledger', color: '#3B8EA5' },
  complete: { label: 'Complete', color: '#3B8EA5' },
}

const pipelineStages = [
  { key: 'queued', label: 'UPLOAD', icon: Upload },
  { key: 'hashing', label: 'HASH', icon: Hash },
  { key: 'vault', label: 'VAULT', icon: Shield },
  { key: 'ocr', label: 'OCR', icon: Search },
  { key: 'extracting', label: 'EXTRACT', icon: FileText },
  { key: 'classified', label: 'CLASSIFY', icon: FileSpreadsheet },
  { key: 'ledger', label: 'LEDGER', icon: CheckCircle2 },
  { key: 'complete', label: 'COMPLETE', icon: CheckCircle2 },
]

function getFileIcon(type: string) {
  if (type.includes('pdf')) return <FileText size={18} color="#E85D4C" />
  if (type.includes('image')) return <FileImage size={18} color="#3B8EA5" />
  if (type.includes('mail') || type.includes('message')) return <Mail size={18} color="#D4A03A" />
  return <FileText size={18} color="#64748B" />
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function generateHash(name: string): string {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    const char = name.charCodeAt(i)
    hash = ((hash << 5) - hash + char) | 0
  }
  return Math.abs(hash).toString(16).padStart(64, '0')
}

export default function DocumentVault() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isDragOver, setIsDragOver] = useState(false)
  const [documents, setDocuments] = useState<UploadedDoc[]>([])
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { speak, isSpeaking, stop } = useTTS()

  const simulateProcessing = useCallback((docId: string) => {
    const stages: UploadedDoc['status'][] = ['hashing', 'vault', 'ocr', 'extracting', 'classified', 'ledger', 'complete']
    let stageIndex = 0

    const advance = () => {
      if (stageIndex >= stages.length) return
      const status = stages[stageIndex]
      const progress = Math.round(((stageIndex + 1) / (stages.length + 1)) * 100)

      setDocuments((prev) =>
        prev.map((d) =>
          d.id === docId
            ? {
                ...d,
                status,
                progress,
                facts: status === 'ledger' ? mockFacts : d.facts,
              }
            : d
        )
      )

      stageIndex++
      if (stageIndex < stages.length) {
        setTimeout(advance, 1200 + Math.random() * 800)
      } else {
        setDocuments((prev) =>
          prev.map((d) => (d.id === docId ? { ...d, progress: 100 } : d))
        )
      }
    }

    setTimeout(advance, 600)
  }, [])

  const addDocument = useCallback(
    (file: File) => {
      const id = `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`
      const newDoc: UploadedDoc = {
        id,
        name: file.name,
        type: file.type,
        size: formatFileSize(file.size),
        status: 'queued',
        hash: generateHash(file.name),
        facts: [],
        progress: 0,
      }
      setDocuments((prev) => [...prev, newDoc])
      simulateProcessing(id)
    },
    [simulateProcessing]
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragOver(false)
      const files = Array.from(e.dataTransfer.files)
      files.forEach(addDocument)
    },
    [addDocument]
  )

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || [])
      files.forEach(addDocument)
      e.target.value = ''
    },
    [addDocument]
  )

  const removeDocument = useCallback((id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id))
    setExpandedDoc((prev) => (prev === id ? null : prev))
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragOver(false)
  }, [])

  // Entrance animation
  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    gsap.fromTo(
      section.querySelector('.vault-header'),
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        ease: 'power2.out',
        scrollTrigger: { trigger: section, start: 'top 80%' },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  const completedCount = documents.filter((d) => d.status === 'complete').length
  const totalFacts = documents.reduce((sum, d) => sum + d.facts.length, 0)

  return (
    <section
      id="vault"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="vault-header mb-10">
          <p className="section-label mb-4">00 — EVIDENCE VAULT</p>
          <h2
            className="text-[36px] md:text-[48px] font-light leading-[1.1] text-[#E2E8F0] mb-4"
            style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}
          >
            Document Intake & Processing
          </h2>
          <p className="text-base font-light text-[#64748B] max-w-[560px] leading-relaxed">
            Upload evidence documents to see them processed through the deterministic pipeline. 
            Each document is hashed, stored immutably, and analysed for extractable facts.
          </p>
        </div>

        {/* Stats bar */}
        {documents.length > 0 && (
          <div className="flex items-center gap-6 mb-6">
            <div className="flex items-center gap-2">
              <Shield size={14} color="#3B8EA5" />
              <span className="font-geist-mono text-[11px] text-[#64748B]">
                {documents.length} document{documents.length !== 1 ? 's' : ''} uploaded
              </span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} color="#3B8EA5" />
              <span className="font-geist-mono text-[11px] text-[#64748B]">
                {completedCount} processed
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Hash size={14} color="#D4A03A" />
              <span className="font-geist-mono text-[11px] text-[#64748B]">
                {totalFacts} facts extracted
              </span>
            </div>
          </div>
        )}

        {/* Upload Area */}
        <div
          className="relative mb-8"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.docx,.doc,.eml,.msg,.txt,.jpg,.jpeg,.png,.tiff"
            onChange={handleFileSelect}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-10 px-6 rounded-xl transition-all duration-300 cursor-pointer"
            style={{
              background: isDragOver ? 'rgba(232, 93, 76, 0.08)' : '#111D32',
              border: isDragOver
                ? '2px dashed #E85D4C'
                : '2px dashed rgba(100, 116, 139, 0.25)',
            }}
            onMouseEnter={(e) => {
              if (!isDragOver) {
                e.currentTarget.style.borderColor = 'rgba(100, 116, 139, 0.4)'
                e.currentTarget.style.background = 'rgba(100, 116, 139, 0.05)'
              }
            }}
            onMouseLeave={(e) => {
              if (!isDragOver) {
                e.currentTarget.style.borderColor = 'rgba(100, 116, 139, 0.25)'
                e.currentTarget.style.background = '#111D32'
              }
            }}
          >
            <div className="flex flex-col items-center gap-3">
              <Upload
                size={28}
                color={isDragOver ? '#E85D4C' : '#64748B'}
                style={{ transition: 'color 0.3s ease' }}
              />
              <p className="font-geist-mono text-sm text-[#E2E8F0]">
                {isDragOver ? 'Drop documents here' : 'Click or drag documents to upload'}
              </p>
              <p className="font-geist-mono text-[10px] text-[#64748B] uppercase tracking-[1px]">
                PDF, DOCX, EML, TXT, Images accepted
              </p>
            </div>
          </button>
        </div>

        {/* Document List */}
        {documents.length > 0 && (
          <div className="flex flex-col gap-3">
            {documents.map((doc) => (
              <DocumentCard
                key={doc.id}
                doc={doc}
                isExpanded={expandedDoc === doc.id}
                onToggle={() => setExpandedDoc(expandedDoc === doc.id ? null : doc.id)}
                onRemove={() => removeDocument(doc.id)}
                onSpeak={(text) => {
                  if (isSpeaking) stop()
                  else speak(text)
                }}
                isSpeaking={isSpeaking}
              />
            ))}
          </div>
        )}

        {/* Empty state hint */}
        {documents.length === 0 && (
          <div
            className="text-center py-12 rounded-xl"
            style={{
              background: '#111D32',
              border: '1px solid rgba(100, 116, 139, 0.1)',
            }}
          >
            <AlertTriangle size={24} color="#64748B" className="mx-auto mb-3 opacity-50" />
            <p className="font-geist-mono text-xs text-[#64748B]">
              No documents in vault. Upload evidence to begin processing.
            </p>
          </div>
        )}
      </div>
    </section>
  )
}

function DocumentCard({
  doc,
  isExpanded,
  onToggle,
  onRemove,
  onSpeak,
  isSpeaking,
}: {
  doc: UploadedDoc
  isExpanded: boolean
  onToggle: () => void
  onRemove: () => void
  onSpeak: (text: string) => void
  isSpeaking: boolean
}) {
  const statusInfo = statusLabels[doc.status]
  const statusIndex = pipelineStages.findIndex((s) => s.key === doc.status)

  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{
        background: '#111D32',
        border: '1px solid rgba(100, 116, 139, 0.12)',
        transition: 'border-color 0.3s ease',
      }}
    >
      {/* Main Row */}
      <div
        className="flex items-center gap-4 px-5 py-4 cursor-pointer"
        onClick={onToggle}
      >
        {/* File icon */}
        <div className="flex-shrink-0">{getFileIcon(doc.type)}</div>

        {/* File info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3">
            <p className="text-sm font-normal text-[#E2E8F0] truncate">{doc.name}</p>
            <span className="font-geist-mono text-[10px] text-[#64748B] flex-shrink-0">
              {doc.size}
            </span>
          </div>

          {/* Mini pipeline */}
          <div className="flex items-center gap-1 mt-2">
            {pipelineStages.map((stage, i) => {
              const StageIcon = stage.icon
              const isActive = i <= statusIndex
              const isCurrent = i === statusIndex && doc.status !== 'complete'
              return (
                <div key={stage.key} className="flex items-center">
                  <div
                    className="flex items-center justify-center rounded"
                    style={{
                      width: 18,
                      height: 18,
                      background: isActive
                        ? isCurrent
                          ? 'rgba(232, 93, 76, 0.2)'
                          : 'rgba(59, 142, 165, 0.15)'
                        : 'rgba(100, 116, 139, 0.08)',
                      transition: 'all 0.5s ease',
                    }}
                    title={stage.label}
                  >
                    <StageIcon
                      size={9}
                      color={isActive ? (isCurrent ? '#E85D4C' : '#3B8EA5') : '#334155'}
                    />
                  </div>
                  {i < pipelineStages.length - 1 && (
                    <div
                      className="w-3 h-px mx-0.5"
                      style={{
                        background: isActive ? '#3B8EA5' : '#1A2744',
                        transition: 'background 0.5s ease',
                      }}
                    />
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {doc.status === 'complete' ? (
            <CheckCircle2 size={14} color="#3B8EA5" />
          ) : doc.status === 'queued' ? (
            <Clock size={14} color="#64748B" />
          ) : (
            <Loader2 size={14} color="#D4A03A" className="animate-spin" />
          )}
          <span
            className="font-geist-mono text-[10px] uppercase tracking-[1px]"
            style={{ color: statusInfo.color }}
          >
            {statusInfo.label}
          </span>
        </div>

        {/* Expand toggle */}
        {doc.facts.length > 0 && (
          <div className="flex-shrink-0">
            {isExpanded ? <ChevronUp size={14} color="#64748B" /> : <ChevronDown size={14} color="#64748B" />}
          </div>
        )}

        {/* Remove */}
        <button
          onClick={(e) => {
            e.stopPropagation()
            onRemove()
          }}
          className="flex-shrink-0 p-1 rounded hover:bg-[#E85D4C20] transition-colors duration-200"
        >
          <X size={12} color="#64748B" />
        </button>
      </div>

      {/* Expanded: Processing Details */}
      {isExpanded && doc.facts.length > 0 && (
        <div
          className="px-5 pb-5"
          style={{ borderTop: '1px solid rgba(100, 116, 139, 0.08)' }}
        >
          {/* Hash */}
          <div className="mt-4 mb-4">
            <p className="font-geist-mono text-[10px] uppercase tracking-[1px] text-[#64748B] mb-1.5">
              SHA-256 Digest
            </p>
            <code className="font-geist-mono text-[10px] text-[#3B8EA5] break-all leading-relaxed block p-2.5 rounded"
              style={{ background: 'rgba(59, 142, 165, 0.05)' }}
            >
              {doc.hash}
            </code>
          </div>

          {/* Facts Table */}
          <div className="mb-3 flex items-center justify-between">
            <p className="font-geist-mono text-[10px] uppercase tracking-[1px] text-[#64748B]">
              Extracted Facts ({doc.facts.length})
            </p>
            <button
              onClick={() =>
                onSpeak(
                  `Extracted ${doc.facts.length} facts from ${doc.name}. ` +
                    doc.facts.map((f) => `${f.subject}: ${f.predicate} on ${f.date}`).join('. ')
                )
              }
              className="flex items-center gap-1.5 px-2 py-1 rounded transition-colors duration-200"
              style={{
                background: isSpeaking ? 'rgba(232, 93, 76, 0.15)' : 'rgba(100, 116, 139, 0.08)',
              }}
            >
              <Volume2 size={10} color={isSpeaking ? '#E85D4C' : '#64748B'} />
              <span className="font-geist-mono text-[9px] uppercase text-[#64748B]">
                {isSpeaking ? 'Speaking' : 'Read aloud'}
              </span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(100, 116, 139, 0.12)' }}>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    ID
                  </th>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    Predicate
                  </th>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    Subject
                  </th>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    Date
                  </th>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    Source
                  </th>
                  <th className="text-left py-2 px-2 font-geist-mono text-[9px] uppercase tracking-[1px] text-[#64748B] font-normal">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {doc.facts.map((fact) => (
                  <tr
                    key={fact.id}
                    className="group"
                    style={{ borderBottom: '1px solid rgba(100, 116, 139, 0.06)' }}
                  >
                    <td className="py-2 px-2 font-geist-mono text-[10px] text-[#3B8EA5]">
                      <div className="flex items-center gap-1">
                        <Link2 size={8} color="#3B8EA5" />
                        {fact.id}
                      </div>
                    </td>
                    <td className="py-2 px-2 font-geist-mono text-[11px] text-[#E2E8F0]">
                      {fact.predicate}
                    </td>
                    <td className="py-2 px-2 text-xs text-[#E2E8F0] font-light">{fact.subject}</td>
                    <td className="py-2 px-2 font-geist-mono text-[10px] text-[#D4A03A]">
                      <div className="flex items-center gap-1">
                        <Calendar size={8} color="#D4A03A" />
                        {fact.date}
                      </div>
                    </td>
                    <td className="py-2 px-2 font-geist-mono text-[10px] text-[#64748B]">
                      [{fact.source}]
                    </td>
                    <td className="py-2 px-2">
                      <span
                        className="font-geist-mono text-[9px] uppercase tracking-[1px] px-1.5 py-0.5 rounded"
                        style={{
                          background:
                            fact.status === 'verified'
                              ? 'rgba(59, 142, 165, 0.12)'
                              : fact.status === 'asserted'
                                ? 'rgba(212, 160, 58, 0.12)'
                                : 'rgba(232, 93, 76, 0.12)',
                          color:
                            fact.status === 'verified'
                              ? '#3B8EA5'
                              : fact.status === 'asserted'
                                ? '#D4A03A'
                                : '#E85D4C',
                        }}
                      >
                        {fact.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Source anchor example */}
          <div className="mt-4 p-3 rounded-lg" style={{ background: 'rgba(59, 142, 165, 0.05)' }}>
            <p className="font-geist-mono text-[9px] uppercase tracking-[1px] text-[#3B8EA5] mb-1.5">
              Source Anchor Format
            </p>
            <p className="font-geist-mono text-[10px] text-[#64748B]">
              [D{doc.id.split('-')[1]?.toUpperCase().slice(0, 3) || '001'} p1 ¶2] → opens evidence viewer on document, page 1, paragraph 2
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
