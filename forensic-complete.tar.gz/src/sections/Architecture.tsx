import { useEffect, useRef, useState, useCallback } from 'react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const layers = [
  {
    label: 'EVIDENCE VAULT',
    short: 'SHA-256 | WORM',
    description: 'Preserve originals immutably. SHA-256 on ingest. WORM storage. Chain of custody.',
    stack: 'S3 Object Lock / Azure immutable blobs; SHA-256; RFC 3161 timestamping',
  },
  {
    label: 'FACT LEDGER',
    short: 'Atomic | Source',
    description: 'Convert sources into atomic litigable facts. Single-purpose, source-bound, never auto-promoted.',
    stack: 'PostgreSQL with JSONB; deterministic parsers; rule DSL',
  },
  {
    label: 'LEGAL MAPPING',
    short: 'Version | Alert',
    description: 'Map facts to legal elements and burdens. Versioned authorities. Stale guidance alerts.',
    stack: 'Rules engine over versioned authority tables; no free-form authority generation',
  },
  {
    label: 'DRAFTING ENGINE',
    short: 'Court | Anchor',
    description: 'Court-ready documents from controlled records only. No unsourced factual clause may pass.',
    stack: 'Server-side templates + constrained generation; LLM as candidate-only',
  },
  {
    label: 'AUDIT ENGINE',
    short: 'Block | Verify',
    description: 'Block defective output before export. Zero critical findings required for release.',
    stack: 'Rule engine + diff engine + citation resolver + transparency log',
  },
]

const asciiTemplate = `+==================+
| {LABEL} |
| {SHORT} |
+=========@========+`

function buildAsciiArt(progress: number): string {
  const totalChars = layers.length * 25 + (layers.length - 1) * 4 // rough count
  let result = ''
  let charCount = 0

  for (let i = 0; i < layers.length; i++) {
    if (i > 0) {
      const connector = `          |\n      @---+---@\n          |\n`
      for (let c = 0; c < connector.length; c++) {
        if (charCount < progress * totalChars) {
          result += connector[c]
        }
        charCount++
      }
    }

    let box = asciiTemplate
    box = box.replace('{LABEL}', layers[i].label.padEnd(16, ' '))
    box = box.replace('{SHORT}', layers[i].short.padEnd(16, ' '))

    for (let c = 0; c < box.length; c++) {
      if (charCount < progress * totalChars) {
        result += box[c]
      }
      charCount++
    }
    if (i < layers.length - 1) result += '\n'
  }

  return result
}

function colorizeAscii(text: string): string {
  return text
    .replace(/#/g, '<span style="color:#E85D4C">#</span>')
    .replace(/@/g, '<span style="color:#D4A03A">@</span>')
    .replace(/\+(=+)(\+|@)/g, (_, eq, end) => `<span style="color:#E85D4C">+${eq}</span><span style="color:#D4A03A">${end}</span>`)
    .replace(/\|/g, '<span style="color:#64748B">|</span>')
    .replace(/=/g, '<span style="color:#64748B">=</span>')
    .replace(/EVIDENCE VAULT|FACT LEDGER|LEGAL MAPPING|DRAFTING ENGINE|AUDIT ENGINE/g, (m) => `<span style="color:#E2E8F0">${m}</span>`)
    .replace(/SHA-256|WORM|Atomic|Source|Version|Alert|Court|Anchor|Block|Verify/g, (m) => `<span style="color:#64748B">${m}</span>`)
}

export default function Architecture() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const asciiRef = useRef<HTMLPreElement>(null)
  const [typedText, setTypedText] = useState('')
  const [hoveredLayer, setHoveredLayer] = useState<number | null>(null)
  const hasTyped = useRef(false)

  const typeInAscii = useCallback(() => {
    if (hasTyped.current) return
    hasTyped.current = true

    const duration = 3000
    const startTime = performance.now()

    const animate = (time: number) => {
      const elapsed = time - startTime
      const progress = Math.min(1, elapsed / duration)
      const text = buildAsciiArt(progress)
      setTypedText(text)

      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }

    requestAnimationFrame(animate)
  }, [])

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: typeInAscii,
      once: true,
    })

    return () => {
      trigger.kill()
    }
  }, [typeInAscii])

  return (
    <section
      id="architecture"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <p className="section-label mb-6">03 — ARCHITECTURE</p>

        {/* 3D Perspective Heading */}
        <PerspectiveHeading text="IMMUTABLE" />

        <div className="flex flex-col lg:flex-row gap-8 mt-12">
          {/* ASCII Connectome */}
          <div className="lg:w-1/2 relative">
            <div
              className="p-6 md:p-10 rounded-xl overflow-x-auto"
              style={{
                background: '#0A1628',
                border: '1px solid rgba(100, 116, 139, 0.15)',
              }}
            >
              <pre
                ref={asciiRef}
                className="font-geist-mono text-[11px] md:text-[13px] leading-[1.3] text-[#64748B]"
                style={{ tabSize: 4 }}
                dangerouslySetInnerHTML={{ __html: colorizeAscii(typedText) || '&nbsp;' }}
              />
            </div>

            {/* Mobile layer selector */}
            <div className="lg:hidden mt-6 flex flex-col gap-2">
              {layers.map((layer, i) => (
                <button
                  key={i}
                  className="text-left p-3 rounded-lg text-sm font-light"
                  style={{
                    background: hoveredLayer === i ? '#1A2744' : '#111D32',
                    border: `1px solid ${hoveredLayer === i ? '#E85D4C40' : 'rgba(100, 116, 139, 0.1)'}`,
                    color: '#E2E8F0',
                    transition: 'all 0.3s ease',
                  }}
                  onClick={() => setHoveredLayer(hoveredLayer === i ? null : i)}
                >
                  <span className="font-geist-mono text-[11px] text-[#64748B]">{i + 1}. </span>
                  {layer.label}
                  {hoveredLayer === i && (
                    <p className="text-xs text-[#64748B] mt-2 font-light leading-relaxed">{layer.description}</p>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Layer details — desktop hover */}
          <div className="hidden lg:flex lg:w-1/2 flex-col gap-4">
            {layers.map((layer, i) => (
              <div
                key={i}
                className="p-5 rounded-lg cursor-default transition-all duration-300"
                style={{
                  background: hoveredLayer === i ? '#1A2744' : '#111D32',
                  border: `1px solid ${hoveredLayer === i ? '#E85D4C40' : 'rgba(100, 116, 139, 0.1)'}`,
                }}
                onMouseEnter={() => setHoveredLayer(i)}
                onMouseLeave={() => setHoveredLayer(null)}
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className="font-geist-mono text-[11px] text-[#E85D4C]">{String(i + 1).padStart(2, '0')}</span>
                  <h3 className="text-base font-normal text-[#E2E8F0]">{layer.label}</h3>
                </div>
                <p className="text-sm font-light text-[#64748B] leading-relaxed mb-2">{layer.description}</p>
                {hoveredLayer === i && (
                  <p className="text-xs font-geist-mono text-[#3B8EA5]">{layer.stack}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function PerspectiveHeading({ text }: { text: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = textRef.current
    if (!el) return

    const chars = el.querySelectorAll('span')
    chars.forEach((span, i) => {
      ;(span as HTMLElement).style.transitionDelay = `${i * 0.04}s`
    })

    const trigger = ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top 80%',
      end: 'top 30%',
      onEnter: () => el.classList.add('revealed'),
      onLeaveBack: () => el.classList.remove('revealed'),
    })

    return () => {
      trigger.kill()
    }
  }, [])

  const characters = text.split('')

  return (
    <div ref={containerRef} className="perspective-container flex items-center justify-center py-4">
      <div
        ref={textRef}
        className="rotate-text font-light uppercase tracking-[-2px] text-[#E2E8F0] text-center"
        style={{
          fontFamily: "'Geist', sans-serif",
          fontSize: 'clamp(36px, 6vw, 80px)',
          transformStyle: 'preserve-3d',
        }}
      >
        {characters.map((char, i) => (
          <span key={i} style={{ display: 'inline-block' }}>
            {char}
          </span>
        ))}
      </div>
    </div>
  )
}
