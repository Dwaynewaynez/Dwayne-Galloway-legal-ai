import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const engines = [
  {
    title: 'Burden of Proof',
    description:
      'Track who must prove what, and to what standard. EqA s136 burden shift triggered only when primary facts support discrimination.',
    badge: 'EVIDENTIAL',
    color: '#E85D4C',
  },
  {
    title: 'Admission Engine',
    description:
      "Isolate express or implied admissions. 'We will take no further action' → flagged as potential admission with exact source span.",
    badge: 'EVIDENTIAL',
    color: '#E85D4C',
  },
  {
    title: 'Chronology Integrity',
    description:
      'Prevent date drift and event conflation. Event date chosen by precedence rule; conflicts marked date_uncertain with alternatives preserved.',
    badge: 'ANTI-HALLUCINATION',
    color: '#3B8EA5',
  },
  {
    title: 'Quote Preservation',
    description:
      'Preserve legally significant wording exactly. Quotes copied only from stored spans; any edit breaks signature and fails audit.',
    badge: 'ANTI-HALLUCINATION',
    color: '#3B8EA5',
  },
  {
    title: 'Hallucination Detector',
    description:
      'Block unsupported factual or legal content. Any noun-date-verb proposition lacking anchor fails export.',
    badge: 'ANTI-HALLUCINATION',
    color: '#3B8EA5',
  },
  {
    title: 'Legal Authority Engine',
    description:
      'Resolve statutes, rules, guidance and cases to current authoritative text. Verify via Find Case Law. Flag stale guidance.',
    badge: 'LEGAL',
    color: '#D4A03A',
  },
  {
    title: 'Contradiction Ranking',
    description:
      'Prioritise contradictions by materiality to element, source quality, directness, and timing.',
    badge: 'ADVERSARIAL',
    color: '#64748B',
  },
  {
    title: 'Judge Mode',
    description:
      'Convert material into what a judge needs fastest. Strip rhetoric, surface material facts/law/remedy.',
    badge: 'STRATEGIC',
    color: '#64748B',
  },
  {
    title: 'Procedural Engine',
    description:
      'Compute deadlines, gateways, forms, service steps. SAR one-month; JR reply 7 days. All deadlines carry legal source.',
    badge: 'LEGAL',
    color: '#D4A03A',
  },
]

export default function Engines() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const grid = gridRef.current
    if (!grid) return

    const cardEls = grid.querySelectorAll('.engine-card')
    gsap.fromTo(
      cardEls,
      { opacity: 0, y: 50 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.08,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: grid,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  return (
    <section
      id="engines"
      ref={sectionRef}
      className="w-full py-24 md:py-40"
      style={{ background: '#0A1628' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-12">
        <p className="section-label mb-6">04 — ENGINES</p>
        <h2
          className="text-[36px] md:text-[48px] font-light leading-[1.1] text-[#E2E8F0] mb-4"
          style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}
        >
          Deterministic services, not free-floating AI
        </h2>
        <p className="text-base font-light text-[#64748B] leading-relaxed max-w-[640px] mb-12">
          Every engine operates over the same controlled ledger — not as probabilistic generators, but as auditable, rule-bound services.
        </p>

        <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {engines.map((engine, i) => (
            <div
              key={i}
              className="engine-card p-7 rounded-lg group"
              style={{
                background: '#111D32',
                border: '1px solid rgba(100, 116, 139, 0.1)',
                borderRadius: '8px',
                transition: 'border-color 0.3s ease, transform 0.3s ease',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = `${engine.color}30`
                el.style.transform = 'translateY(-2px)'
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = 'rgba(100, 116, 139, 0.1)'
                el.style.transform = 'translateY(0)'
              }}
            >
              <span
                className="inline-block font-geist-mono text-[10px] uppercase tracking-[1px] px-2.5 py-1 rounded mb-4"
                style={{
                  background: `${engine.color}18`,
                  color: engine.color,
                }}
              >
                {engine.badge}
              </span>
              <h3 className="text-lg font-normal text-[#E2E8F0] mb-3">{engine.title}</h3>
              <p className="text-sm font-light text-[#64748B] leading-relaxed">
                {engine.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
