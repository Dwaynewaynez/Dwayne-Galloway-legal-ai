import { useEffect, useRef } from 'react'

const nodes = [
  { cx: 160, cy: 438, label: 'DOC', phase: 0.1 },
  { cx: 320, cy: 378, label: 'FACT', phase: 0.3 },
  { cx: 480, cy: 540, label: 'EVT', phase: 0.6 },
  { cx: 640, cy: 702, label: 'AUTH', phase: 0.9 },
  { cx: 800, cy: 540, label: 'DOC', phase: 1.2 },
  { cx: 960, cy: 380, label: 'FACT', phase: 1.5 },
  { cx: 1120, cy: 540, label: 'EVT', phase: 1.8 },
  { cx: 1280, cy: 700, label: 'AUTH', phase: 2.1 },
  { cx: 1440, cy: 540, label: 'DOC', phase: 2.4 },
  { cx: 1600, cy: 378, label: 'FACT', phase: 2.7 },
]

const paths = [
  { d: 'M 0 540 Q 480 340, 960 540 T 1920 540', gradId: 'grad1', yBase: 540, amplitude: 200 },
  { d: 'M 0 380 Q 480 220, 960 380 T 1920 380', gradId: 'grad2', yBase: 380, amplitude: 160 },
  { d: 'M 0 700 Q 480 560, 960 700 T 1920 700', gradId: 'grad3', yBase: 700, amplitude: 140 },
]

export default function Hero() {
  const svgRef = useRef<SVGSVGElement>(null)
  const rafRef = useRef<number>(0)
  const startTimeRef = useRef<number>(0)

  useEffect(() => {
    const svg = svgRef.current
    if (!svg) return

    startTimeRef.current = performance.now()

    const animate = (time: number) => {
      const elapsed = (time - startTimeRef.current) / 1000

      // Animate gradient offsets (signal traveling)
      paths.forEach((_, i) => {
        const gradStops = svg.querySelectorAll(`#grad${i + 1} stop`)
        if (gradStops.length >= 4) {
          const offset = ((elapsed * 25 + i * 33) % 220) - 110
          gradStops[0].setAttribute('offset', `${offset - 10}%`)
          gradStops[1].setAttribute('offset', `${offset + 40}%`)
          gradStops[2].setAttribute('offset', `${offset + 60}%`)
          gradStops[3].setAttribute('offset', `${offset + 110}%`)
        }
      })

      // Animate node glows
      nodes.forEach((node, i) => {
        const glow = svg.querySelector(`#node-glow-${i}`)
        if (glow) {
          const cycle = ((elapsed - node.phase) * Math.PI) / 1.5
          const opacity = Math.max(0, Math.sin(cycle) * 0.4)
          glow.setAttribute('opacity', String(opacity))
        }
      })

      // Grid pulse - every 3s
      const pulsePhase = (elapsed % 3) / 3
      const gridCrosses = svg.querySelectorAll('.grid-cross')
      gridCrosses.forEach((cross, i) => {
        const crossCycle = ((pulsePhase * gridCrosses.length + i) % gridCrosses.length) / gridCrosses.length
        const crossOpacity = crossCycle < 0.3 ? 0.03 + crossCycle * 0.17 : 0.08 - (crossCycle - 0.3) * 0.05
        cross.setAttribute('opacity', String(Math.max(0.03, Math.min(0.08, crossOpacity))))
      })

      rafRef.current = requestAnimationFrame(animate)
    }

    rafRef.current = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(rafRef.current)
    }
  }, [])

  // Generate hex grid points
  const hexPoints: { x: number; y: number }[] = []
  const cols = 12
  const rows = 12
  const xSpacing = 160
  const ySpacing = 92
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const xOffset = row % 2 === 0 ? 0 : 80
      hexPoints.push({
        x: col * xSpacing + xOffset + 40,
        y: row * ySpacing + 20,
      })
    }
  }

  // Generate grid cross markers (5x5)
  const crossMarkers: { x: number; y: number }[] = []
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      crossMarkers.push({
        x: col * 400 + 200,
        y: row * 220 + 110,
      })
    }
  }

  const handleExploreClick = (e: React.MouseEvent) => {
    e.preventDefault()
    const target = document.querySelector('#showcase')
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="relative w-full min-h-[100dvh] overflow-hidden" style={{ background: '#0A1628' }}>
      {/* SVG Connectome */}
      <svg
        ref={svgRef}
        viewBox="0 0 1920 1080"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full"
        role="img"
        aria-label="Animated forensic evidence network showing documents, facts, events, and authorities connected by traveling signal paths"
      >
        <title>Forensic Evidence Connectome</title>

        <defs>
          {paths.map((p) => (
            <linearGradient key={p.gradId} id={p.gradId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="-10%" stopColor="#E85D4C" stopOpacity="0" />
              <stop offset="40%" stopColor="#E85D4C" stopOpacity="0.8" />
              <stop offset="60%" stopColor="#D4A03A" stopOpacity="0.8" />
              <stop offset="110%" stopColor="#D4A03A" stopOpacity="0" />
            </linearGradient>
          ))}
          <pattern id="scanlines" width="4" height="4" patternUnits="userSpaceOnUse">
            <line x1="0" y1="3" x2="4" y2="3" stroke="#E2E8F2" strokeWidth="0.5" opacity="0.02" />
          </pattern>
        </defs>

        {/* Background */}
        <rect width="1920" height="1080" fill="#0A1628" />

        {/* Scanlines */}
        <rect width="1920" height="1080" fill="url(#scanlines)" />

        {/* Hex grid points */}
        {hexPoints.map((p, i) => (
          <circle key={`hex-${i}`} cx={p.x} cy={p.y} r="1" fill="#1A2744" opacity="0.5" />
        ))}

        {/* Grid cross markers */}
        {crossMarkers.map((c, i) => (
          <g key={`cross-${i}`} className="grid-cross" stroke="#E2E8F2" strokeWidth="1" opacity="0.03">
            <line x1={c.x - 8} y1={c.y} x2={c.x + 8} y2={c.y} />
            <line x1={c.x} y1={c.y - 8} x2={c.x} y2={c.y + 8} />
          </g>
        ))}

        {/* Signal paths */}
        {paths.map((p, idx) => (
          <path
            key={`path-${idx}`}
            d={p.d}
            fill="none"
            stroke={`url(#${p.gradId})`}
            strokeWidth="2"
            strokeLinecap="round"
          />
        ))}

        {/* Active nodes */}
        {nodes.map((node, i) => (
          <g key={`node-${i}`}>
            {/* Glow */}
            <circle
              id={`node-glow-${i}`}
              cx={node.cx}
              cy={node.cy}
              r="18"
              fill="#E85D4C"
              opacity="0"
            />
            {/* Core */}
            <circle
              cx={node.cx}
              cy={node.cy}
              r="6"
              fill="#0A1628"
              stroke="#E2E8F0"
              strokeWidth="2"
            />
            {/* Label */}
            <text
              x={node.cx}
              y={node.cy - 28}
              textAnchor="middle"
              fill="#64748B"
              fontFamily="'Geist Mono', monospace"
              fontSize="9"
              fontWeight="400"
              textRendering="optimizeLegibility"
            >
              {node.label}
            </text>
          </g>
        ))}
      </svg>

      {/* Text Overlay */}
      <div
        className="absolute bottom-[12vh] left-6 md:left-12 z-10 max-w-[700px]"
        style={{ textShadow: '0 2px 40px rgba(10, 22, 40, 0.9)' }}
      >
        <p className="font-geist-mono text-[11px] uppercase tracking-[3px] text-[#64748B] mb-4">
          DETERMINISTIC EVIDENCE SYSTEM
        </p>
        <h1 className="text-[36px] md:text-[56px] font-light leading-[1.1] text-[#E2E8F0] mb-6" style={{ fontFamily: "'Geist', sans-serif", letterSpacing: '-0.5px' }}>
          Every fact traceable. Every citation verifiable. Every output auditable.
        </h1>
        <p className="text-base md:text-lg font-light text-[#64748B] max-w-[520px] leading-relaxed mb-8">
          A litigation operating system with immutable evidence vaults, forensic fact ledgers, and deterministic chronology engines — designed for court-facing deployment.
        </p>
        <a
          href="#showcase"
          onClick={handleExploreClick}
          className="inline-block font-geist-mono text-xs uppercase tracking-[2px] text-[#E85D4C] hover:underline underline-offset-4 transition-all duration-300"
        >
          Explore the Architecture →
        </a>
      </div>
    </section>
  )
}
