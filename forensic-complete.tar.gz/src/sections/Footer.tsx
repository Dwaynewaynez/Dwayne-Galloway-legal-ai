export default function Footer() {
  return (
    <footer
      className="w-full py-10 px-6 md:px-12"
      style={{
        background: '#0A1628',
        borderTop: '1px solid rgba(100, 116, 139, 0.15)',
      }}
    >
      <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <span className="font-geist-mono text-sm tracking-[4px] text-[#E2E8F0]">
          FORENSIC
        </span>

        <span className="text-[13px] font-light text-[#64748B]">
          © 2025 Deterministic Evidence Systems
        </span>

        <span className="font-geist-mono text-[11px] uppercase tracking-[2px] text-[#64748B]">
          Built for England & Wales civil procedure
        </span>
      </div>
    </footer>
  )
}
